create view view_permission_user as /* ALGORITHM=UNDEFINED */
select `ssm_shiro`.`t_permission`.`id`         AS `id`,
       `ssm_shiro`.`t_permission`.`name`       AS `name`,
       `ssm_shiro`.`t_permission`.`menuname`   AS `menuname`,
       `ssm_shiro`.`t_permission`.`permission` AS `permission`,
       `ssm_shiro`.`t_permission`.`url`        AS `url`,
       `ssm_shiro`.`t_permission`.`flag`       AS `flag`,
       `ssm_shiro`.`t_permission`.`zindex`     AS `zindex`,
       `ssm_shiro`.`t_permission`.`parantid`   AS `parantid`,
       `ssm_shiro`.`t_user_role`.`user_id`     AS `userid`
from ((`ssm_shiro`.`t_user_role` left join `ssm_shiro`.`t_role_permission` on ((`ssm_shiro`.`t_user_role`.`role_id` =
                                                                                `ssm_shiro`.`t_role_permission`.`role_id`)))
       left join `ssm_shiro`.`t_permission`
                 on ((`ssm_shiro`.`t_role_permission`.`permission_id` = `ssm_shiro`.`t_permission`.`id`)));

