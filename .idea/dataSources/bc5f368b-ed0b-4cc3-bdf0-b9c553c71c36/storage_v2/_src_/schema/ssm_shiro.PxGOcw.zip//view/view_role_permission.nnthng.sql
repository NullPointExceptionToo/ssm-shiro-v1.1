create view view_role_permission as /* ALGORITHM=UNDEFINED */
select `ssm_shiro`.`t_role`.`id`               AS `id`,
       `ssm_shiro`.`t_role`.`name`             AS `name`,
       `ssm_shiro`.`t_role`.`sn`               AS `sn`,
       `ssm_shiro`.`t_permission`.`id`         AS `permissionId`,
       `ssm_shiro`.`t_permission`.`name`       AS `permissionname`,
       `ssm_shiro`.`t_permission`.`menuname`   AS `menuname`,
       `ssm_shiro`.`t_permission`.`permission` AS `permission`,
       `ssm_shiro`.`t_permission`.`url`        AS `url`,
       `ssm_shiro`.`t_permission`.`flag`       AS `flag`,
       `ssm_shiro`.`t_permission`.`zindex`     AS `zindex`,
       `ssm_shiro`.`t_permission`.`parantid`   AS `parantid`
from ((`ssm_shiro`.`t_role` left join `ssm_shiro`.`t_role_permission` on ((`ssm_shiro`.`t_role`.`id` = `ssm_shiro`.`t_role_permission`.`role_id`)))
       left join `ssm_shiro`.`t_permission`
                 on ((`ssm_shiro`.`t_role_permission`.`permission_id` = `ssm_shiro`.`t_permission`.`id`)));

