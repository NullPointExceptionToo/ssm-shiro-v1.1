create view view_role_user as /* ALGORITHM=UNDEFINED */
select distinct `ssm_shiro`.`t_role`.`id`           AS `id`,
                `ssm_shiro`.`t_role`.`name`         AS `name`,
                `ssm_shiro`.`t_role`.`sn`           AS `sn`,
                `ssm_shiro`.`t_user_role`.`user_id` AS `user_id`
from (`ssm_shiro`.`t_user_role`
       left join `ssm_shiro`.`t_role` on ((`ssm_shiro`.`t_role`.`id` = `ssm_shiro`.`t_user_role`.`role_id`)));

