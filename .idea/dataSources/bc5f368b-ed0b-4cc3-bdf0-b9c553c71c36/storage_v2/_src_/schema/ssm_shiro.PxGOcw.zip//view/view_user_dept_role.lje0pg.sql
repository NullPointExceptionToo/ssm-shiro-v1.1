create view view_user_dept_role as /* ALGORITHM=UNDEFINED */
select `ssm_shiro`.`t_user`.`id`              AS `id`,
       `ssm_shiro`.`t_user`.`dept_id`         AS `dept_id`,
       `ssm_shiro`.`t_user`.`staffname`       AS `staffname`,
       `ssm_shiro`.`t_user`.`username`        AS `username`,
       `ssm_shiro`.`t_user`.`password`        AS `password`,
       `ssm_shiro`.`t_user`.`status`          AS `status`,
       `ssm_shiro`.`t_dept`.`name`            AS `deptname`,
       `ssm_shiro`.`t_role`.`name`            AS `rolename`,
       `ssm_shiro`.`t_role`.`id`              AS `roleId`,
       `ssm_shiro`.`t_dept`.`id`              AS `deptId`,
       `ssm_shiro`.`t_class`.`id`             AS `collegeClassId`,
       `ssm_shiro`.`t_user`.`collegeClass_id` AS `collegeClass_id`,
       `ssm_shiro`.`t_faculty`.`id`           AS `facultyid`,
       `ssm_shiro`.`t_user`.`faculty_id`      AS `faculty_id`,
       `ssm_shiro`.`t_class`.`classname`      AS `collegeClassName`,
       `ssm_shiro`.`t_faculty`.`facultyname`  AS `facultyname`
from (((((`ssm_shiro`.`t_user` left join `ssm_shiro`.`t_dept` on ((`ssm_shiro`.`t_user`.`dept_id` = `ssm_shiro`.`t_dept`.`id`))) left join `ssm_shiro`.`t_user_role` on ((`ssm_shiro`.`t_user`.`id` = `ssm_shiro`.`t_user_role`.`user_id`))) left join `ssm_shiro`.`t_role` on ((`ssm_shiro`.`t_user_role`.`role_id` = `ssm_shiro`.`t_role`.`id`))) left join `ssm_shiro`.`t_class` on ((`ssm_shiro`.`t_user`.`collegeClass_id` = `ssm_shiro`.`t_class`.`id`)))
       left join `ssm_shiro`.`t_faculty` on ((`ssm_shiro`.`t_user`.`faculty_id` = `ssm_shiro`.`t_faculty`.`id`)));

